Unzip and pop in your mod folder.

Took me way longer than I would like to admit because I have never coded in my life.

Adds the singular joker: Chudjoker, bringing all listed probabilities to a near-zero chance. (But not nothing!)

Thanks to u/BenJammin007 for the idea!

Version 1.0.0 -

Chudjoker Launch


1.0.1 -

Buffed (nerfed?) Chudjoker to lower global probabilities by a factor of v/1000, increased from launch factor of v/10