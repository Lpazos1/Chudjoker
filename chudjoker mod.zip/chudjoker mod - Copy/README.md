Unzip and pop in your mod folder.

Took me way longer than I would like to admit because I have never coded in my life.

Adds the singular joker: Chudjoker, bringing all listed probabilities to a near-zero chance. (But not nothing!)